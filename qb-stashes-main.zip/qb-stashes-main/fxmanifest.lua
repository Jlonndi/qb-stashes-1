fx_version 'cerulean'
game 'gta5'

description 'QB-Stashes'
version '1.0.0'

shared_script 'config.lua'

client_script 'cl_stashes.lua'
