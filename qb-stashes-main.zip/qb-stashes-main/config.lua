Config = {}

Config.PoliceOpen = true -- Can Police open all stashes

Config.Stashes = {
    -- ["geminimansion"] = {
    --     stashName = "geminimansion",
    --     coords = vector3(-1730.5, 358.6, 88.73), 
    --     requirecid = true,
    --     jobrequired = false,
    --     gangrequired = false,
    --     gang = "",
    --     job = "",
    --     cid = {"MAH44286"},  
    --     stashSize = 1250000,
    --     stashSlots = 125, 
    -- },
}